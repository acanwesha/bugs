package com.resultcopy.service;
import com.mysql.cj.jdbc.Driver;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Date;
import java.util.HashMap;
import java.util.Properties;

/**
 * Connect to Database
 * @author AC089545
 */
public class ConnectionFactory {
    private static ConnectionFactory connectionFactory;
    /**
     * Get a connection to database
     * @return Connection object
     */
    public static Connection getConnection() throws IOException {
        HashMap<String,String> configMap = getPropValues();

        String URL = configMap.get("url");
        String USER = configMap.get("user") ;
        String PASS = configMap.get("password");


        try {
            DriverManager.registerDriver(new Driver());
            return DriverManager.getConnection(URL, USER, PASS);
        } catch (SQLException ex) {
            throw new RuntimeException("Error connecting to the database", ex);
        }
    }


    public static HashMap<String,String> getPropValues() throws IOException {
        String result = "";
        InputStream inputStream = null;
        HashMap<String,String> configMap = new HashMap<String,String>();

        try {
            Properties prop = new Properties();
            String propFileName = "application.properties";

            inputStream = ConnectionFactory.class.getClassLoader().getResourceAsStream(propFileName);

            if (inputStream != null) {
                prop.load(inputStream);
            } else {
                throw new FileNotFoundException("property file '" + propFileName + "' not found in the classpath");
            }

            Date time = new Date(System.currentTimeMillis());

            // get the property value and print it out
            String user = prop.getProperty("USER");
            String url = prop.getProperty("URL");
            String password = prop.getProperty("PASS");
            configMap.put("url",url);
            configMap.put("user",user);
            configMap.put("password",password);

            result = "Company List = " + url + ", " + user + ", " + password;
            System.out.println(result + "\nProgram Ran on " + time + " by user=" + user);

        } catch (Exception e) {
            System.out.println("Exception: " + e);
        } finally {
            inputStream.close();
        }
        return configMap;
    }

}

